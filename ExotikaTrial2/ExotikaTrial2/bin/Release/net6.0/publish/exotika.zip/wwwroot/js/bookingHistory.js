﻿
//var dataTable;

//$(document).ready(function () {
//    loadDataTable();
//});

//function loadDataTable() {
//    dataTable = $('#tblData').DataTable({
//        "ajax": {
//            "url": "/UserSpecific/Tourists/GetAll",
//        },
//        "columns": [
//            { "data": "package.name", "width": "15%" },
//            { "data": "resort.name", "width": "15%" },
//            { "data": "resort.city", "width": "15%" },
//            { "data": "createDate", "width": "10%" },
//            {
//                "data": "bookingID",
//                "render": function (data) {
//                    return `
//                        <div class="w-75 mb-2 btn-group" role="group">
//                            <a href="/UserSpecific/Tourists/BookingDetail?bookingId=${data}">View Details</a>
//                        </div>
//                    `;
//                },
//                "width": "5%"
//            },
//        ]
//    });
//}


//$(document).ready(function () {
//    $('#tblData').DataTable();
//});


	//$(document).ready(function() {
	//	$("#tblData").fancyTable({
	//		sortColumn: 0,
	//		pagination: true,
	//		perPage: 10,
	//		globalSearch: true
	//	});		
	//});
